# Apollo Scraper — Final Monorepo

Run `run.ps1 -ApifyToken "YOUR_TOKEN"` to build and run locally using Docker.
