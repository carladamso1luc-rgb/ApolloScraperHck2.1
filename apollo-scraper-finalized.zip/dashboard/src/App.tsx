import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
export default function ApolloScraperDashboard(){ 
  const [actorId, setActorId] = useState("");
  const [inputJson, setInputJson] = useState(`{
  "startUrls": ["https://apollo.io/companies/example"],
  "cookie": "",
  "maxResults": 250,
  "concurrency": 2,
  "filters": { "emailOnly": true }
}`);
  const [status, setStatus] = useState("Idle");
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState("");
  const [downloadLinks, setDownloadLinks] = useState({});
  const [isRunning, setIsRunning] = useState(false);

  const getToken = async () => {
    const res = await fetch("/get-token", { method: "POST" });
    if (!res.ok) throw new Error("Failed to get token");
    const { token } = await res.json();
    return token;
  };

  const startRun = async () => {
    if (!actorId) { alert("Please provide Actor ID"); return; }
    let parsedInput;
    try { parsedInput = JSON.parse(inputJson); } catch (e) { alert("Invalid JSON input"); return; }
    setIsRunning(true); setStatus("Starting actor run...");
    try {
      const token = await getToken();
      const resp = await fetch(`/start`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ actorId, input: parsedInput }) });
      const data = await resp.json();
      if (!resp.ok) { setStatus("Start failed: " + (data.error || JSON.stringify(data))); setIsRunning(false); return; }
      const runId = data.runId || data.data?.id;
      setStatus(`Run started: ${runId}`);
      pollStatus(runId, token);
      streamLogs(runId);
    } catch (err) { setStatus("Error starting run: " + err.message); setIsRunning(false); }
  };

  const pollStatus = (runId, token) => {
    const interval = setInterval(async () => {
      try {
        const r = await fetch(`/status/${encodeURIComponent(runId)}`);
        const j = await r.json();
        const runStatus = j.status || j.data?.status;
        setStatus(`Run status: ${runStatus}`);
        const progressMap = { READY:10, RUNNING:50, SUCCEEDED:100, FAILED:100, ABORTED:100 };
        setProgress(progressMap[runStatus] || 0);
        if (["SUCCEEDED","FAILED","ABORTED"].includes(runStatus)) {
          clearInterval(interval); setIsRunning(false);
          if (runStatus === "SUCCEEDED") {
            const storId = j.storeId || j.data?.defaultKeyValueStoreId;
            if (storId) {
              setDownloadLinks({
                csv: `/download/${storId}/results.csv`,
                txt: `/download/${storId}/results.txt`,
                zip: `/download/${storId}/results.zip`
              });
            }
          }
        }
      } catch (err) { setStatus("Polling error: " + err.message); clearInterval(interval); setIsRunning(false); }
    }, 4000);
  };

  const streamLogs = (runId) => {
    const evtSource = new EventSource(`/logs/${encodeURIComponent(runId)}`);
    evtSource.onmessage = (e) => {
      try { const d = JSON.parse(e.data); setLogs(prev => prev + "\n" + (d.message || JSON.stringify(d))); } catch { setLogs(prev => prev + "\n" + e.data); }
    };
    evtSource.onerror = () => evtSource.close();
  };

  return (
    <div style={{minHeight:'100vh',background:'#000',color:'#fff',padding:24}}>
      <div style={{maxWidth:900,margin:'0 auto'}}>
        <h1 style={{color:'#00ff99'}}>Apollo Scraper Dashboard</h1>
        <div style={{background:'#111',padding:16,borderRadius:12}}>
          <label>Actor ID</label>
          <input style={{width:'100%',padding:8,marginTop:8,background:'#060606',color:'#fff'}} value={actorId} onChange={e=>setActorId(e.target.value)} placeholder="user~actor-name" />
          <label style={{marginTop:8}}>Input JSON</label>
          <textarea style={{width:'100%',height:160,marginTop:8,background:'#060606',color:'#fff',fontFamily:'monospace'}} value={inputJson} onChange={e=>setInputJson(e.target.value)} />
          <div style={{display:'flex',gap:8,marginTop:12}}>
            <button onClick={startRun} disabled={isRunning} style={{padding:'8px 12px',background:'#00ffa2',color:'#000',borderRadius:6}}>{isRunning?'Running...':'Start Scrape'}</button>
            <button onClick={()=>{ if (!downloadLinks.csv) alert('No results yet'); else window.open(downloadLinks.csv); }} style={{padding:'8px 12px',borderRadius:6}}>Download CSV</button>
          </div>
          <div style={{marginTop:12}}>
            <p>Status: <strong>{status}</strong></p>
            <div style={{height:10,background:'#222',borderRadius:6,overflow:'hidden'}}><motion.div style={{height:10,background:'#00ffa2',width:`${progress}%`}} animate={{width:`${progress}%`}} /></div>
          </div>
          <pre style={{background:'#030303',padding:10,borderRadius:8,marginTop:12,height:180,overflow:'auto'}}>{logs||'No logs yet'}</pre>
        </div>
      </div>
    </div>
  );
}