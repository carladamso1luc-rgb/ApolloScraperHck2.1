const express = require('express');
const cors = require('cors');
const axios = require('axios');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const app = express();
app.use(cors()); app.use(express.json());
const RATE_LIMIT = Number(process.env.RATE_LIMIT_PER_MIN || 120);
const recentRequests = new Map();
app.use((req,res,next)=>{ try{ const ip = req.ip || req.connection.remoteAddress || 'local'; const now = Date.now(); const windowStart = now - 60000; const arr = recentRequests.get(ip) || []; const filtered = arr.filter(ts => ts > windowStart); filtered.push(now); recentRequests.set(ip, filtered); if (filtered.length > RATE_LIMIT) { res.status(429).json({ error: 'Rate limit exceeded' }); return; } }catch(e){} next(); });
const APIFY_TOKEN = process.env.APIFY_TOKEN || '';
if (!APIFY_TOKEN) console.warn('APIFY_TOKEN not set in environment. Server will not be able to start actor runs.');
const JWT_SECRET = process.env.JWT_SECRET || 'replace_this_with_a_real_secret';
app.post('/get-token', (req, res) => {
    const token = jwt.sign({ canStart: true }, JWT_SECRET, { expiresIn: '5m' });
    res.json({ token });
});
app.post('/start', async (req, res) => {
    const { actorId, input } = req.body;
    if (!actorId) return res.status(400).json({ error: 'actorId required' });
    try {
        const url = `https://api.apify.com/v2/acts/${encodeURIComponent(actorId)}/runs?token=${APIFY_TOKEN}`;
        const r = await axios.post(url, { input });
        const runId = r.data.data?.id || r.data?.id;
        return res.json({ runId });
    } catch (e) {
        return res.status(500).json({ error: e.message, details: e.response?.data });
    }
});
app.get('/status/:runId', async (req, res) => {
    const runId = req.params.runId;
    try {
        const url = `https://api.apify.com/v2/runs/${encodeURIComponent(runId)}?token=${APIFY_TOKEN}`;
        const r = await axios.get(url);
        const data = r.data.data || r.data;
        const status = data?.status || 'UNKNOWN';
        const storeId = data?.defaultKeyValueStoreId || null;
        res.json({ status, storeId, data });
    } catch (e) {
        res.status(500).json({ error: e.message, details: e.response?.data });
    }
});
// serve dashboard static if available
const dashboardDist = path.join(__dirname, '..', 'dashboard', 'dist');
if (fs.existsSync(dashboardDist)){
    app.use('/', express.static(dashboardDist));
    app.get('*', (req,res)=> res.sendFile(path.join(dashboardDist, 'index.html')));
}
app.get('/logs/:runId', async (req, res) => {
    const runId = req.params.runId;
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.flushHeaders();
    let stopped = false;
    req.on('close', () => { stopped = true; });
    let last = 0;
    while (!stopped) {
        try {
            const url = `https://api.apify.com/v2/acts/runs/${encodeURIComponent(runId)}/logs?token=${APIFY_TOKEN}&offset=${last}`;
            const r = await axios.get(url);
            const lines = r.data?.logs || [];
            for (const ln of lines) {
                res.write(`data: ${JSON.stringify(ln)}\n\n`);
                last = ln.seq ?? last + 1;
            }
        } catch (e) {
            res.write(`data: ${JSON.stringify({ error: true, message: e.message })}\n\n`);
        }
        await new Promise(resolve => setTimeout(resolve, 2000));
    }
    res.end();
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));