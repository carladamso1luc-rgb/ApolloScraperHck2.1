param(
  [string]$ApifyToken,
  [string]$JwtSecret = "supersecret"
)
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Error "Docker not found. Please install Docker Desktop and try again."
  exit 1
}
Write-Host "Building docker image..."
docker build -t apollo-scraper .
if ($LASTEXITCODE -ne 0) { Write-Error "Docker build failed"; exit 1 }
Write-Host "Running container on http://localhost:3000 ..."
docker run -it --rm -p 3000:3000 -p 4000:4000 -e APIFY_TOKEN=$ApifyToken -e JWT_SECRET=$JwtSecret apollo-scraper
