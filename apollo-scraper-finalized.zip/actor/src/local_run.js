/**
 * actor/src/local_run.js - local Playwright runner
 * Usage: node src/local_run.js <url1> <url2> ...
 * Requires: npm install playwright libphonenumber-js csv-stringify archiver
 */
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const stringify = require('csv-stringify/lib/sync');
const { chromium } = require('playwright');
const { parsePhoneNumberFromString } = require('libphonenumber-js');

async function normalizeRecord(r){
    const rec = {
        name: (r.name || '').replace(/\s+/g,' ').trim(),
        title: (r.title || '').replace(/\s+/g,' ').trim(),
        email: (r.email || '').trim(),
        company: (r.company || '').trim(),
        location: (r.location || '').trim(),
        phone: r.phone ? r.phone.trim() : '',
        source: r.source || ''
    };
    if (rec.phone) {
        try { const p = parsePhoneNumberFromString(rec.phone); if (p && p.isValid()) rec.phone = p.formatInternational(); } catch(e){}
    }
    return rec;
}

async function run(urls){
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();
    const results = [];
    const seen = new Set();
    for (const url of urls){
        try {
            await page.goto(url, { waitUntil:'domcontentloaded', timeout:30000 });
            await page.waitForTimeout(800 + Math.random()*800);
            const found = await page.evaluate(()=>{
                const items = [];
                const emailRegex = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
                Array.from(document.querySelectorAll('a[href^="mailto:"]')).forEach(a=>{
                    const href = a.getAttribute('href') || ''; const email = href.replace(/^mailto:/i, '').split('?')[0].trim();
                    const container = a.closest('div') || a.parentElement;
                    const name = container?.querySelector('[class*=name], [data-test*=name]')?.textContent || '';
                    const title = container?.querySelector('[class*=title], [data-test*=title]')?.textContent || '';
                    items.push({name: name?.trim(), title: title?.trim(), company:'', phone:'', email, source: location.href});
                });
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
                let node; const seen = new Set();
                while(node = walker.nextNode()) {
                    const text = node.nodeValue || '';
                    const matches = text.match(emailRegex);
                    if (matches) matches.forEach(m=>{ if(!seen.has(m)){ seen.add(m); const parent = node.parentElement; const name = parent?.querySelector('[class*=name], [data-test*=name]')?.textContent || ''; const title = parent?.querySelector('[class*=title], [data-test*=title]')?.textContent || ''; items.push({name: name?.trim(), title: title?.trim(), company:'', phone:'', email: m, source: location.href}); }});
                }
                return items;
            });
            for (const r of found){
                const rec = await normalizeRecord(r);
                const key = rec.email + '::' + (rec.name||'');
                if (seen.has(key)) continue;
                seen.add(key);
                results.push(rec);
            }
        } catch(e){
            console.error('Error loading', url, e.message);
        }
    }
    await browser.close();
    const csv = stringify(results, { header: true });
    fs.writeFileSync(path.join(__dirname, '..', 'results.csv'), csv);
    fs.writeFileSync(path.join(__dirname, '..', 'results.jsonl'), results.map(r=>JSON.stringify(r)).join('\n'));
    console.log('Saved results to results.csv and results.jsonl');
    return results;
}

if (require.main === module){
    const args = process.argv.slice(2);
    let urls = [];
    if (args.length > 0) urls = args;
    else {
        const p = path.join(__dirname, '..', 'actor_input_example.json');
        if (fs.existsSync(p)) {
            const j = JSON.parse(fs.readFileSync(p,'utf8'));
            urls = j.startUrls || [];
        }
    }
    run(urls).then(()=>process.exit(0)).catch(()=>process.exit(1));
}