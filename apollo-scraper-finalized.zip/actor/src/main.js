/**
 * actor/src/main.js
 * Apify Actor - Apollo.io contact scraper (educational / supervised use only)
 * Safe features: normalization, phone formatting, optional MX validation, chunking, exports (CSV/TXT/JSONL/ZIP).
 * DOES NOT contain captcha solving or proxy-evasion code.
 */
const Apify = require('apify');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const stringify = require('csv-stringify/lib/sync');
const { parsePhoneNumberFromString } = require('libphonenumber-js');
const dns = require('dns').promises;

Apify.main(async () => {
    const input = await Apify.getInput();
    const {
        startUrls = [], cookie = '', maxResults = 250, concurrency = 2,
        filters = {}, useApifyProxy = true, notifyOnCaptcha = true, validateEmailMX = false
    } = input || {};

    const MIN_RESULTS = 100;
    const MAX_RESULTS = 2500;
    let cappedMax = Number(maxResults) || 250;
    if (cappedMax < MIN_RESULTS) cappedMax = MIN_RESULTS;
    if (cappedMax > MAX_RESULTS) cappedMax = MAX_RESULTS;

    Apify.utils.log.info(`Configured maxResults: ${cappedMax} (input requested: ${input && input.maxResults})`);

    if (!startUrls || startUrls.length === 0) {
        Apify.utils.log.info('No start URLs provided. Exiting.');
        return;
    }

    const requestQueue = await Apify.openRequestQueue();
    for (const url of startUrls) await requestQueue.addRequest({ url });

    const dataset = await Apify.openDataset();
    const kvStore = await Apify.openKeyValueStore();

    const proxyConfiguration = await Apify.createProxyConfiguration({ useApifyProxy });

    function normalizeRecord(r){
        const rec = {
            name: (r.name || '').replace(/\s+/g,' ').trim(),
            title: (r.title || '').replace(/\s+/g,' ').trim(),
            email: (r.email || '').trim(),
            company: (r.company || '').trim(),
            location: (r.location || '').trim(),
            phone: r.phone ? r.phone.trim() : '',
            source: r.source || ''
        };
        if (rec.phone) {
            try {
                const p = parsePhoneNumberFromString(rec.phone);
                if (p && p.isValid()) rec.phone = p.formatInternational();
            } catch(e){ /* ignore */ }
        }
        return rec;
    }

    async function verifyEmailMX(email){
        if (!email || typeof email !== 'string') return false;
        const domain = email.split('@')[1];
        if (!domain) return false;
        try {
            const mx = await dns.resolveMx(domain);
            return Array.isArray(mx) && mx.length > 0;
        } catch (e) {
            return false;
        }
    }

    const seen = new Set();

    const crawler = new Apify.PlaywrightCrawler({
        requestQueue,
        proxyConfiguration,
        launchContext: { launchOptions: { headless: true } },
        maxConcurrency: concurrency,
        handlePageTimeoutSecs: 120,
        maxRequestRetries: 3,
        handlePageFunction: async ({ page, request }) => {
            Apify.utils.log.info(`Processing ${request.url}`);
            await Apify.utils.sleep(500 + Math.random()*800);

            if (cookie) {
                try {
                    const pairs = cookie.split(';').map(s => s.trim()).filter(Boolean);
                    for (const pair of pairs) {
                        const idx = pair.indexOf('=');
                        if (idx > 0) {
                            const name = pair.slice(0, idx).trim();
                            const value = pair.slice(idx+1).trim();
                            await page.context().addCookies([{ name, value, domain: '.apollo.io', path: '/' }]);
                        }
                    }
                } catch(e){ Apify.utils.log.warning('Cookie parse failed: ' + e.message); }
            }

            const html = await page.content();
            if (/captcha|are you human|hcaptcha|recaptcha|bot verification/i.test(html)) {
                Apify.utils.log.warning('Captcha detected on ' + request.url);
                if (notifyOnCaptcha) {
                    const ss = await page.screenshot();
                    await kvStore.setValue('captcha-'+Date.now()+'.png', ss, { contentType: 'image/png' });
                }
                throw new Error('CaptchaDetected');
            }

            const found = await page.evaluate(() => {
                const items = [];
                const emailRegex = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/ig;
                Array.from(document.querySelectorAll('a[href^="mailto:"]')).forEach(a=>{
                    const href = a.getAttribute('href') || ''; const email = href.replace(/^mailto:/i, '').split('?')[0].trim();
                    const container = a.closest('div') || a.parentElement;
                    const name = container?.querySelector('[class*=name], [data-test*=name]')?.textContent || '';
                    const title = container?.querySelector('[class*=title], [data-test*=title]')?.textContent || '';
                    const phone = container?.querySelector('[class*=phone], [data-test*=phone]')?.textContent || '';
                    const company = container?.querySelector('[class*=company]')?.textContent || '';
                    items.push({name: name?.trim(), title: title?.trim(), company: company?.trim(), phone: phone?.trim(), email, source: location.href});
                });
                const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
                let node;
                const seen = new Set();
                while(node = walker.nextNode()) {
                    const text = node.nodeValue || '';
                    const matches = text.match(emailRegex);
                    if (matches) matches.forEach(m=>{ if(!seen.has(m)){ seen.add(m); const parent = node.parentElement; const name = parent?.querySelector('[class*=name], [data-test*=name]')?.textContent || ''; const title = parent?.querySelector('[class*=title], [data-test*=title]')?.textContent || ''; const phone = parent?.querySelector('[class*=phone], [data-test*=phone]')?.textContent || ''; const company = parent?.querySelector('[class*=company]')?.textContent || ''; items.push({name: name?.trim(), title: title?.trim(), company: company?.trim(), phone: phone?.trim(), email: m, source: location.href}); }});
                }
                return items;
            });

            for (const r of (found || [])) {
                const rec = normalizeRecord(r);
                if (!rec.email) continue;
                const key = `${rec.email}::${rec.name || ''}`;
                if (seen.has(key)) continue;
                if (validateEmailMX) {
                    try {
                        const ok = await verifyEmailMX(rec.email);
                        if (!ok) {
                            Apify.utils.log.debug('MX validation failed for ' + rec.email);
                            rec.mxValidated = false;
                        } else rec.mxValidated = true;
                    } catch(e){ rec.mxValidated = false; }
                }
                seen.add(key);
                await dataset.pushData(rec);

                const total = (await dataset.getData({ limit: 0 })).total || 0;
                if (total >= cappedMax) {
                    Apify.utils.log.info('Reached configured maxResults. Stopping crawl.');
                    throw new Error('MaxResultsReached');
                }
            }

            try {
                const next = await page.$('a[rel="next"]');
                if (next) {
                    const href = await next.getAttribute('href');
                    if (href) await requestQueue.addRequest({ url: new URL(href, request.loadedUrl || request.url).href });
                }
            } catch(e){ /* ignore */ }
        },
        handleFailedRequestFunction: async ({ request }) => {
            Apify.utils.log.error('Request failed too many times: ' + request.url);
        }
    });

    Apify.utils.log.info('Starting crawler...');
    try {
        await crawler.run();
    } catch(e){
        if (e.message === 'MaxResultsReached') {
            Apify.utils.log.info('Crawl stopped after reaching max results.');
        } else {
            Apify.utils.log.warning('Crawler error: ' + e.message);
        }
    }

    const data = await dataset.getData({ limit: cappedMax });
    const records = data.items || [];

    const csv = stringify(records, { header: true });
    await kvStore.setValue('results.csv', csv, { contentType: 'text/csv' });

    const jsonl = records.map(r => JSON.stringify(r)).join('\\n');
    await kvStore.setValue('results.jsonl', jsonl, { contentType: 'application/json' });

    const txt = jsonl;
    await kvStore.setValue('results.txt', txt, { contentType: 'text/plain' });

    const tmpZip = path.join('/tmp', `results-${Date.now()}.zip`);
    await new Promise((resolve, reject)=>{
        const output = fs.createWriteStream(tmpZip);
        const archive = archiver('zip', { zlib: { level: 9 } });
        output.on('close', resolve);
        archive.on('error', reject);
        archive.pipe(output);
        archive.append(csv, { name: 'results.csv' });
        archive.append(txt, { name: 'results.txt' });
        archive.append(jsonl, { name: 'results.jsonl' });
        archive.finalize();
    });
    const buffer = fs.readFileSync(tmpZip);
    await kvStore.setValue('results.zip', buffer, { contentType: 'application/zip' });
    Apify.utils.log.info('Exports saved to key-value store.');
});